from django.contrib import admin
from .models import Degree
admin.site.register(Degree)
from .models import Office
admin.site.register(Office)
from .models import User
admin.site.register(User)
# Register your models here.
